// some scripts

// jquery ready start
$(document).ready(function() {
	// jQuery code

    
}); 
// jquery end



